dos('./SGF iterative/1.png iterative/1.png iterative/1_30iter.png 16 0.1 0.1 30');
dos('./SGF iterative/2.png iterative/2.png iterative/2_8iter.png 16 0.1 0.1 8');
dos('./SGF iterative/3.png iterative/3.png iterative/3_20iter.png 16 0.1 0.1 20');
dos('./SGF iterative/4.png iterative/4.png iterative/4_20iter.png 16 0.1 0.1 20');
