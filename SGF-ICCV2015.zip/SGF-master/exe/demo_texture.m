dos('SGF.exe texture/1.png texture/1.png texture/1_smooth.png 10 0.065 0.1 6');
dos('SGF.exe texture/2.png texture/2.png texture/2_smooth.png 12 0.065 0.1 6');
dos('SGF.exe texture/3.png texture/3.png texture/3_smooth.png 16 0.065 0.1 4');
dos('SGF.exe texture/4.png texture/4.png texture/4_smooth.png 12 0.065 0.1 4');
dos('SGF.exe texture/5.png texture/5.png texture/5_smooth.png 12 0.065 0.1 3');
dos('SGF.exe texture/6.png texture/6.png texture/6_smooth.png 12 0.065 0.1 6');
dos('SGF.exe texture/7.png texture/7.png texture/7_smooth.png 12 0.065 0.1 6');